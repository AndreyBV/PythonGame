# Hopfield-Network
Реализация нейросети Хопфилда в PyQt5.
Ссылка на информацию о быстрой сборке exe файла
https://pylab.ru/how-to-create-exe-in-python/
